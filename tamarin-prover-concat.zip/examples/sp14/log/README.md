This folder will contain the generated log output from running the
group-protocol case studies in the sp14 folder.